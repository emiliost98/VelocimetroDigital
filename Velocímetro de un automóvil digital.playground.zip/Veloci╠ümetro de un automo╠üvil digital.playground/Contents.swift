import UIKit

enum Velocidades : Int{
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init (velocidadInicial : Velocidades){
        self = .Apagado
    }
}

class Auto{
    var velocidad : Velocidades
    init(velocidad : Velocidades) {
        self.velocidad = .Apagado
    }
    
    func cambioDeVelocidad()-> ( actual : Int, velocidadEnCadena: String) {
      var actual = 0
        var velocidadEnCadena = ""
        
    
        if velocidad == Velocidades.Apagado {
            velocidad = Velocidades.VelocidadBaja
            actual = Velocidades.VelocidadBaja.rawValue
            velocidadEnCadena = "Baja"
        }else if velocidad == Velocidades.VelocidadBaja {
            velocidad = Velocidades.VelocidadMedia
            actual = Velocidades.VelocidadMedia.rawValue
            velocidadEnCadena = "Media"
        }else if velocidad == Velocidades.VelocidadMedia {
            velocidad = Velocidades.VelocidadAlta
            actual = Velocidades.VelocidadAlta.rawValue
            velocidadEnCadena = "Alta"
        }else if velocidad == Velocidades.VelocidadAlta {
            velocidad = Velocidades.VelocidadMedia
            actual = Velocidades.VelocidadMedia.rawValue
            velocidadEnCadena = "Media"
        }
        
        
        let tupla = (actual,velocidadEnCadena)
        return tupla
    }
}

var auto = Auto(velocidad: .Apagado)

for i in 1...20{
    if i <= 20 {
    print(auto.cambioDeVelocidad())
    }
}
